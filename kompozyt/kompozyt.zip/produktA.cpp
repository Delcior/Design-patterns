//
// Created by Kacper on 04.05.2020.
//

#include "produktA.h"

void produktA::sprzedaj() {
    std::cout<<"produkt A jest sprzedawany\n";
}
